package controller;

import static org.junit.Assert.*;

public class ImageProcessingControllerTest {

}