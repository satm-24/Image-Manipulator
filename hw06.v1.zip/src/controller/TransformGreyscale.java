package controller;

import model.IProcessingImageModel;
import model.ImageProcessingUtils;
import model.TransformationType;
import model.operations.ColorTransformation;
import view.Layer;
import view.ILayer;

/**
 * Represents a command to transform the model to greyscale.
 */
 class TransformGreyscale implements ImageProcessingCommand {

  @Override
  public void execute(IProcessingImageModel m, IProcessingController controller) {
    ImageProcessingUtils.checkNotNull(m, "Model cannot be null.");
    ImageProcessingUtils.checkNotNull(controller, "Controller cannot be null.");
    ILayer current = new Layer(controller.getCurrent().getVisibility(),
        m.operate(new ColorTransformation(TransformationType.GREYSCALE)), controller.getCurrent()
        .getName());
    controller.setCurrentInLayers(current);
    controller.setCurrent(current);
  }
}
