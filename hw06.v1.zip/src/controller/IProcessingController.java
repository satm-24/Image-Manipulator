package controller;

import java.util.List;
import view.ILayer;

/**
 * Represents an interface for controllers in our image processing software.
 */
public interface IProcessingController {

  /**
   * Parses user input and directs the controller accordingly.
   */
  void parseInput();

  /**
   * Gets this controller's list of layers.
   *
   * @return the list of layers
   */
  List<ILayer> getLayers();

  /**
   * Gets the current layer.
   *
   * @return the current layer
   */
  ILayer getCurrent();

  /**
   * Sets the current layer to the given layer.
   *
   * @param current the layer to set the current layer to
   */
  void setCurrent(ILayer current);

  /**
   * Removes the current layer from the list of layers.
   */
  void removeCurrent();

  /**
   * Sets the current layer in the list of layers to the given layer.
   *
   * @param layer the layer the current layer to be set to
   */
  void setCurrentInLayers(ILayer layer);
}
