package view;

import java.io.IOException;
import javax.swing.ImageIcon;

/**
 * Represents a basic view for our image processing software, which prints out errors to the
 * console.
 */
public class TextView implements IProcessingImageView {

  private final Appendable out;

  /**
   * Constructs an object of our view with a model and an appendable object to add all our desired
   * view messages to.
   *
   * @param out the appendable object that we are appending our messages to
   */
  public TextView(Appendable out) {
    this.out = out;
  }

  @Override
  public void renderMessage(String message) {
    try {
      this.out.append(message);
    } catch (IOException e) {
      throw new IllegalStateException("could not append to appendable");
    }
  }

  @Override
  public void setImage(ImageIcon image) {
    try {
      this.out.append("image set");
    } catch (IOException e) {
      throw new IllegalStateException("could not append");
    }
  }

  @Override
  public void requestViewFocus() {
    try {
      this.out.append("view focus set");
    } catch (IOException e) {
      throw new IllegalStateException("could not append");
    }
  }

  @Override
  public void setUpLayerSelection(String name) {
    try {
      this.out.append("layer selection set up");
    } catch (IOException e) {
      throw new IllegalStateException("could not append");
    }
  }

  @Override
  public void addViewEventListener(IViewListener listener) {
    try {
      this.out.append("listener added");
    } catch (IOException e) {
      throw new IllegalStateException("could not append");
    }
  }

  @Override
  public void clearLayerSelection() {
    try {
      this.out.append("layer selection cleared");
    } catch (IOException e) {
      throw new IllegalStateException("could not append");
    }
  }
}