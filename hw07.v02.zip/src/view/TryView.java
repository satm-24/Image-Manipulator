package view;

public class TryView {
  public static void main(String [] args) {
    GraphicalView window = new GraphicalView();
  }
}
